#include <iostream>
#include <vector>

using namespace std;

void generateSpiralMatrix() {
    int currentRow = 0;  // Starting row index
    int currentColumn = 0;  // Starting column index
    int columnLimit = 0;
    int inputValue;

    cout << "Please enter the number of rows for the spiral matrix: ";
    cin >> inputValue;

    int matrixSize = inputValue * inputValue;
    int value = 1;

    vector<vector<int>> spiralMatrix(inputValue, vector<int>(inputValue, 0));

    while (value <= matrixSize) {
        while (currentColumn < inputValue - 1) {  // Move along the top row
            spiralMatrix[currentRow][currentColumn] = value;
            value++;
            currentColumn++;
        }
        while (currentRow < inputValue - 1) {  // Move along the last column
            spiralMatrix[currentRow][currentColumn] = value;
            value++;
            currentRow++;
        }
        while (currentColumn > columnLimit) {  // Move along the last row
            spiralMatrix[currentRow][currentColumn] = value;
            value++;
            currentColumn--;
        }
        while (currentRow > columnLimit) {  // Move along the first column
            spiralMatrix[currentRow][currentColumn] = value;
            value++;
            currentRow--;
        }
        inputValue--;
        currentRow++;
        currentColumn++;
        columnLimit++;
        if (value == matrixSize) {  // For odd matrix size
            spiralMatrix[currentRow][currentColumn] = value;
            break;
        }
    }

    cout << "Spiral matrix is:" << endl;
    for (const auto& row : spiralMatrix) {
        for (int element : row) {
            cout << element << " ";
        }
        cout << endl;
    }
}

int main() {
    generateSpiralMatrix();
    return 0;
}

