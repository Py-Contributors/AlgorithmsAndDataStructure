#include <iostream>
#include <unordered_map>
#include <string>

class Node {
public:
    int data;
    Node* left;
    Node* right;

    Node(int data) : data(data), left(nullptr), right(nullptr) {}
};

std::string inorder(Node* root, std::unordered_map<std::string, int>& subtreeFrequency) {
    if (root == nullptr) {
        return "";
    }

    std::string subtreeString = "(";
    subtreeString += inorder(root->left, subtreeFrequency);
    subtreeString += std::to_string(root->data);
    subtreeString += inorder(root->right, subtreeFrequency);
    subtreeString += ")";
    
    if (subtreeFrequency.find(subtreeString) != subtreeFrequency.end() && subtreeFrequency[subtreeString] == 1) {
        std::cout << root->data << " ";
    }

    if (subtreeFrequency.find(subtreeString) != subtreeFrequency.end()) {
        subtreeFrequency[subtreeString] += 1;
    } else {
        subtreeFrequency[subtreeString] = 1;
    }

    return subtreeString;
}

int main() {
    Node* root = new Node(1);
    root->left = new Node(2);
    root->right =  new Node(3);
    root->left->left = new Node(4);
    root->right->left = new Node(2);
    root->right->left->left = new Node(4);

    std::unordered_map<std::string, int> subtreeFrequency;
    inorder(root, subtreeFrequency);

    // Clean up dynamically allocated memory
    delete root->right->left->left;
    delete root->right->left;
    delete root->left->left;
    delete root->left;
    delete root;

    return 0;
}

